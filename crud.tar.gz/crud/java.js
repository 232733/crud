function revealMessage() {
    document.getElementById("hiddenMessage").style.display = "block";
}


function revealMessage2() {
    document.getElementById("hiddenMessage2").style.display = "block";
}

function revealMessage3() {
    document.getElementById("hiddenMessage3").style.display = "block";
}